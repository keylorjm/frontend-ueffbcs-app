import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MatDivider,
  MatDividerModule
} from "./chunk-NQWMCJTZ.js";
import "./chunk-QJVLQKZV.js";
import "./chunk-ODYX3DR4.js";
import "./chunk-WRULZO5C.js";
import "./chunk-QAGZQHUI.js";
import "./chunk-4VHHS2NW.js";
import "./chunk-DAQKJJRP.js";
import "./chunk-ZVWDWOQO.js";
import "./chunk-WV253EFK.js";
import "./chunk-2UVUUPPC.js";
import "./chunk-C27DBZK2.js";
import "./chunk-K54IFBYX.js";
import "./chunk-6DU2HRTW.js";
export {
  MatDivider,
  MatDividerModule
};
