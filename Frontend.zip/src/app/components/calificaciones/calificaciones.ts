import { Component } from '@angular/core';

@Component({
  selector: 'app-calificaciones',
  imports: [],
  templateUrl: './calificaciones.html',
  styleUrl: './calificaciones.scss'
})
export class Calificaciones {

}
